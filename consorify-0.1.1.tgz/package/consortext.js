var consoredWords=['sad','bad','mad'];
var customConsoredWords=[];
function consor(inStr){
    for(idx in consoredWords){
        inStr = inStr.replace(consoredWords[idx], '****');
    }
    for(idx in customConsoredWords){
        inStr = inStr.replace(customConsoredWords[idx],'****');
    }
    return inStr;
}
function addConsortedWord(word){
    customConsoredWords.push(word);
}
function getCensoredWord(){
    return consoredWords.concat(customConsoredWords);
}
exports.censor;
exports.addConsortedWord=addConsortedWord;
exports.getCensoredWord=getCensoredWord;